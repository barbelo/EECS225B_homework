f = imread('checkerboard1024-shaded.tif');
[M, N] = size(f);
% will perform division, so f has to be float
f = intScaling4e(f);
% Display the result
figure, imshow(f)

%%
% padding parameters
P = 2*M;
Q = 2*N;
% The idea is to blue the image enough so that the squares are
% completely smoothed out, leaving only the shading pattern. Use an
% aggressive blurring filter (determined experimentally)
H = lpFilterTF4e('gaussian',P,Q,7);

% Filter the image to obtain the shading pattern
g = dftFiltering4e(f,H);

% Display the result
% scale the intensity to the full [0,1] range for display
figure, imshow(intScaling4e(g,'full'))

%%
% the corrected image is obtained by dividing the original image by 
% the shading pattern. This is elementwise division
fout = f./g;
% Scale the shading pattern and the corrected image so their
% intensities span the full intensity scale [0,1]
g = intScaling4e(g, 'full');
fout = intScaling4e (fout, 'full');
% Display the corrected image
figure, imshow(fout)
