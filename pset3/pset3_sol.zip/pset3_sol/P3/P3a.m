f = imread('testpattern1024.tif');
[M, N] = size(f);
% padding parameters
P = 2*M;
Q = 2*N;
% Gaussian Filter, the value of DP was determined experimentally
H = lpFilterTF4e('gaussian',P,Q,10);
g = dftFiltering4e(f,H);
% Display the result
figure, imshow(g)