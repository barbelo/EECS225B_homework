f = imread('testpattern1024.tif');
[M, N] = size(f);
% padding parameters
P = 2*M;
Q = 2*N;
% Negative of the image
f = intXform4e(f, 'negative'); % This is a project function
% Display the result
figure, imshow(f)

%%
% Butterworth filter (parameters determined experimentally). The
% idea is to produce a severely blurred image
H = lpFilterTF4e('butterworth', P, Q, [8,2]);
% Filter the image
g = dftFiltering4e(f,H);
% Display the result
figure, imshow(g)

%%
% Threshold the function at a high level, say 80% of max value
% (determined experimentally)
gT = g > 0.8*max(g(:));
% Display the result
figure, imshow(gT)
