function H = laplacianTF4e(P,Q)
% Laplacian transfer function in the frequency domain.
% H = LAPLACIANTF4E(P,Q) computes the Laplacian transfer function
% in the frequency domain H. Parameters P and Q are the padded sizes
% used for filtering in the frequency domain. H is centered in the P*Q
% frequency rectangle.

Ucenter = floor(P/2) + 1;
Vcenter = floor(Q/2) + 1;
U = 0:P-1;
V = 0:Q-1;
% center of the frequency rectangle
U = U-Ucenter;
V = V-Vcenter;

% Coordinates
[v,u]=meshgrid(V,U);

% Laplacian filter transfer function 
H = -4*(pi^2)*(u.^2 + v.^2);
