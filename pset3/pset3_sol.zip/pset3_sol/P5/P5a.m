% Read the image and convert values to the floating point range [0,1]
f = intScaling4e(imread('thumb_print.tif'));
% Display the original image
figure, imshow(f)

%% 
[M, N] = size(f);
% padding parameters
P = 2*M;
Q = 2*N;
% Highpass filter transfer function
H = hpFilterTF4e('butterworth', P, Q, [50,4]);
% Filter the image
g = dftFiltering4e(f,H);
% Display the result
figure, imshow(g)

%%
% Threshold the filtering image so that all values>=0 are set to 1
% Negative values are set to 0
gT = g>=0;
% Display the thresholded image
figure, imshow(gT)

