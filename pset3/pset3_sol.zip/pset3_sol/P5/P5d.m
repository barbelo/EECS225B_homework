% Read the image and convert values to the floating point range [0,1]
f = intScaling4e(imread('orig_chest_xray.tif'));
% Display the original image
figure, imshow(f)
%%
[M, N] = size(f);
% padding parameters
P = 2*M;
Q = 2*N;
% Highpass filter transfer function
H = hpFilterTF4e('gaussian', P, Q, 70);
% Filter the image
ghp = dftFiltering4e(f,H);
% Display the result
figure, imshow(intScaling4e(ghp,'full'))

%%
% high frequency emphasis
Hemp = 0.5 + 0.75*H;
gemp = dftFiltering4e(f,Hemp);
% Display the result
figure, imshow(intScaling4e(gemp,'full'))

%%
% gemp is floating point. Convert to 8 bits for use in project function
% histEqual4e
gemp8 = uint8(mat2gray(gemp)*255);
% Histogram equalization
gempEq = histEqual4e(gemp8);

% Display the histogram euqlaized image from the previous step. This result
% agrees with Fig. 4.57(d)
figure, imshow(gempEq)