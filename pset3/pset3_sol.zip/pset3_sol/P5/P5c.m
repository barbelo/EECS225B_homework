% Read the image and convert values to the floating point range [0,1]
f = intScaling4e(imread('blurry-moon.tif'));
% Display the original image
figure, imshow(f)

%%
[M, N] = size(f);
% padding parameters
P = 2*M;
Q = 2*N;

% Laplacian transfer function
% Remember: H is negative
H = laplacianTF4e(P,Q);
% Filterf with H.
lap = dftFiltering4e(f,H);
% Due to filter values and FFT scaling, the range of values of lap
% typically is far larger than the range of values in the originial image,
% which is [0,1]. One way to bring the values within a comparable range is
% to divide lap by its maximum values so that its maximum values will be 1
% (it is important that its negative values be kept)
lap = lap/(max(lap(:)));
% Display the result
figure, imshow(lap)

%%
% H is negative, so we set c=-1 when adding the filtered image to the
% original (see Eq 4-126)
g = f - lap;

% Display the result
figure, imshow(g)
