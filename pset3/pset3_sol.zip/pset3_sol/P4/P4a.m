f = imread('blurry-moon.tif');
[M, N] = size(f);
f = intScaling4e(f);
% Display the result
figure, imshow(f)
%%
% padding parameters
P = 2*M;
Q = 2*N;
% Lowpass filter transfer function, a cutoff frequency D0=50
% (approx 10% of the image width) gave good results. but the method
% is not particularly sensitive to the amount of the blurring, provided
% that image features are bot obliterated beyond recognition
H = lpFilterTF4e('gaussian',P,Q,50);
% Blur the image
fblurred = dftFiltering4e(f,H);
% Display the result
figure, imshow(fblurred)

%%
% mask
mask = f-fblurred;
% Display the mask
figure, imshow(intScaling4e(mask,'full'))

%%
% add mask to the image to create the sharpened result
funsharp = f + mask;

% Display the result
figure, imshow(funsharp)

