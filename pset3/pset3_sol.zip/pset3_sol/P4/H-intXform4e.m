function H-intXform4e
%function [g,map] = intXform4e(f,mode,param)
%   [G,MAP] = INTXFORM4E(F,MODE,PARAM) performs an intensity
%   transformation on 8-bit grayscale image F, as specified in MODE.
%   Values for MODE and the actions performed are as follows:
%
%      MODE      ACTION ON INTESITY VALUES        COMMENTS
%	'negative'  Negative                     Eq. (3-3) in DIP4E      
%	'log'       Natural log transformation   Eq. (3-4) in DIP4E
%	'gamma'     Gamma transformation         Eq. (3-5) in DIP4E
%	'external'  Depends on values provided   User provides 
%                                            transformation in
%                                            PARAM
%
%   Parameter PARAM is a 1-D array that must contain any values
%   needed to implement the specified transformation. If PARAM is
%   not included in the call, then a default value of 1.0 for gamma
%   is used. As stated in the project statement, c = 1.0 in all
%   cases. Option 'external' requires that PARAM be especified.
%   Because we are dealing with 8-bit images, the external function
%   must have 256 values. In addition, all values of the
%   transformation must be in the interval [0,1]). On the output,
%   MAP is the transformation computed by the function (or provided
%   by the user) and G is the transformed function with values in
%   the full range [0,1].

