function H-hpFilterTF4e
%function H = hpFilterTF4e(type,P,Q,param)
%   H = HPFILTERTF4E(TYPE,P,Q,PARAM) generates a circularly-
%   symmetric frequency domain highpass filter transfer function of
%   size P-by-Q. On the output, H is the filter transfer function.
% 
%   The specifications for generating H are as follows. Note that
%   the equations cited describe centered filter transfer functions.
%
%     TYPE              PARAM           REMARKS
%   'ideal'             D0              See Eq. (4-119) in DIP4E
%   'gaussian'          D0              See Eq. (4-120) in DIP4E
%   'butterworth'       [D0, n]         See Eq. (4-121) in DIP4E
%
%   PARAM is a scalar in the first two cases, but it is a vector in
%   the third.
%
%   A highpass transfer function is generated from the correponding
%   lowpass function.
%
%   HP = 1 - LP
%
%   Function lpFilterTF4e is used to compute the lowpass filter
%   transfer function.
%
%   A NOTE REGARDING FILTER SIZE. If H is going to be used in
%   conjunction with filtering function dftFiltering4e, remember
%   that this function pads the input image to size P-by-Q, so H has
%   to be of that size also.

