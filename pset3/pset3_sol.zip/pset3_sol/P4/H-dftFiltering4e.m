function H-dftFiltering4e
%function g = dftFiltering4e(f,H,padmode,scaling)
%   G = DFTFILTERING4E(F,H,PADMODE,SCALING) filters image F using
%   filter transfer function H. The output is of the same size as
%   the input. The function uses replicate padding if PADMODE =
%   'replicate' or is not included in the argument. If PADMODE =
%   'zeros', zero-padding is used. If PADMODE = 'none' no padding is
%   used. In the first two cases, the 'post' option of padding
%   discussed in project function IMPAD4E from Chapter 3 is used.
%   SCALING is an extra option. If it is 'yes', the intensity values
%   of the output image are scaled to the full range [0,1]. If it is
%   'no' or is omitted from the function call, no scaling is used.
%
%   REGARDING THE FILTER TRANSFER FUNCTION, H. Unless padmode =
%   'none', function DFTFILTERING4E pads the input image to size
%   P-by-Q, with P = 2*M and Q = 2*N, where M and N are the number
%   of rows and columns in the image. H has to be of that size also.
%   If padmode = 'none', then P = M, Q = N, and H must be of size
%   M-by-N. It is required that H be provided already centered on
%   the P-by-Q frequency rectangle. Project functions lpFilteTF4e
%   and hpFilterTF4e provide centered tranfer functions.
%
%   The code for this function is based on the filtering procedure
%   discussed in Section 4.7 of DIP4E.

