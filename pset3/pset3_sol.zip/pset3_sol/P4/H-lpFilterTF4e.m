function H-lpFilterTF4e
%function H = lpFilterTF4e(type,P,Q,param)
%   H = LPFILTERTF4E(TYPE,P,Q,PARAM) generates a circularly
%   symmetric frequency domain lowpass filter transfer function of
%   size P-by-Q. On the output, H is the filter transfer function.
% 
%   The specifications for generating H are as follows. Note that
%   the equations referenced are for centered filter transfer
%   functions.
%
%     TYPE              PARAM           REMARKS
%
%   'ideal'             D0              See Eq. (4-111) in DIP4E
%   'gaussian'          D0              See Eq. (4-116) in DIP4E
%   'butterworth'       [D0,n]          See Eq. (4-117) in DIP4E
%
%   Observe that PARAM is a scalar in the first two cases, but it is
%   a vector in the third.
%
%   REGARDING FILTER SIZE. If H is going to be used in conjunction
%   with filtering function dftFiltering4e, keep in mind that
%   dfdFilering4e pads the input image to size P-by-Q, so H has to
%   be of that size also.


