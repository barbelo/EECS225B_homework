function H-imPad4e
%function g = imPad4e(f,R,C,padtype,loc,padval)
%   G = IMPAD4E(F,R,C) pads image F by adding R rows of zeros above
%   and below the image, and C columns of zeros to the left and
%   right of it.
%
%   G = IMPAD4E(F,R,C,PADTYPE,LOC,PADVAL). As above, F is the image
%   to be padded, and R and C are the number of rows and columns to
%   use for padding. PADTYPE can be one of three strings: 'zeros',
%   'constant', or 'replicate'. If 'zeros' is specified, padding is
%   done with 0's. If 'constant' is specified, the padding value is
%   specified as nonnegative integer PADVAL (defaults to 0 if not
%   included in the function call). If 'replicate' is used, padding
%   is done by replicating the 1st and/or last rows and columns of
%   the image. If LOC = 'post', padding is appended to the last row
%   and column of the image. If LOC = 'pre' padding is appended
%   before the first row and/or col. If LOC = 'both', padding is
%   appended before the 1st row and col, and after the last row and
%   col (this is the default). For example, if we set g =
%   imPad4e(f,3,2,'replicate','both') this function pads f by
%   inserting 3 copies of the row at the top of the image, 2 copies
%   of the first col to the left, 3 copies of the last row at the
%   end, and 2 copies of the last column to the right.
%
%   NOTE: This function is a slight generalization of the statement
%   in Project 3.1.

