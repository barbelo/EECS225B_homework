function H-imageHist4e
%function h = imageHist4e(f,mode)
%   H = IMAGEHIST4E(F,MODE) computes the histogram of image F. If
%   MODE = 'n' the output histogram H is normalized. This is the
%   default if MODE is not included in the function call. Otherwise,
%   if MODE = 'u' the histogram is unnormalized. The input image is
%   assumed to be a 256-level grayscale image with positive
%   intensity values. The output histogram has 256 bins, one bin for
%   each possible intensity value in an 8-bit image. If the
%   intensity values in the input image are in the range [0,1], then
%   the 256 bins in H correspond to 256 equally-spaced intensity
%   values in the range [0,1]; otherwise, the bins correspond to 256
%   integer intensity values in the range [0,255]. In either case,
%   H(1) corresponds to intensity value 0.

