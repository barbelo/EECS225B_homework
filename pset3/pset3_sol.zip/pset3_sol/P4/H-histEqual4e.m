function H-histEqual4e
%function g = histEqual4e(f)
%   G = HISTEQUAL4E(F) Histogram equalizes 8-bit, grayscale image F.
%   Output G is the equalized image withintensities in the range
%   [0,1].

