function H-idft2D4e
%Ifunction f = idft2D4e(F)
%   f =IDFT2D4E(f) Computes the inverse 2D dft of input F. The
%   function uses a forward transform to compute the inverse, as
%   explained in Section 4.11 of DIP4E. 

