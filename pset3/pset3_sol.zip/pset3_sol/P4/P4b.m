f = imread('blurry-moon.tif');
[M, N] = size(f);
f = intScaling4e(f);
% Display the result
figure, imshow(f)
%%
% padding parameters
P = 2*M;
Q = 2*N;
% Lowpass filter transfer function, a cutoff frequency D0=50
% (approx 10% of the image width) gave good results. but the method
% is not particularly sensitive to the amount of the blurring, provided
% that image features are bot obliterated beyond recognition
H = lpFilterTF4e('gaussian',P,Q,50);
% Blur the image
fblurred = dftFiltering4e(f,H);
% mask
mask = f-fblurred;
% add mask to the image to create the sharpened result
funsharp = f + mask;
% Boost filtering. Values of k between 1.5 and 2.5 gave improved 
% result over unsharp masking for this image
fboost = f + 2*mask;
% Display the result
figure, imshow(fboost)

